from shopping.urls import path
from .views import (
    basic, cloth, cart_view, signup,
    CustomLoginView, logout_view, delete_account,
    add_to_cart, delete_item, delete_all_items, checkout,
    save_cart, load_cart, place_order
)

urlpatterns = [
    path('', basic, name='basic'),
    path('cloth/', cloth, name='cloth'),
    path('signup/', signup, name='signup'),
    path('login/', CustomLoginView.as_view(), name='login'),
    path('logout/', logout_view, name='logout'),
    path('delete-account/', delete_account, name='delete_account'),
    # Cart & Order
    path('cart/', cart_view, name='cart'),
    path('add-to-cart/', add_to_cart, name='add-to-cart'),
    path('delete-item/<int:item_id>/', delete_item, name='delete_item'),
    path('delete-all-items/', delete_all_items, name='delete_all_items'),
    path('checkout/', checkout, name='checkout'),
    path('save-cart/', save_cart, name='save_cart'),
    path('load-cart/', load_cart, name='load_cart'),
    path('place-order/', place_order, name='place_order'),
    # path('logout',logout_view,name="logout")
    #   path('add-to-cart/', add_to_cart, name='add-to-cart'),
    # path('api/load-cart/', load_cart, name='load_cart'),
    # path('api/save-cart/', save_cart, name='save_cart'),
    # path('api/place-order/', place_order, name='place_order'),
]


