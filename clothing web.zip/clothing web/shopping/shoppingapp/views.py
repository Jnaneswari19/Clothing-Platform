from django.shortcuts import render, redirect
from django.contrib.auth.views import LoginView
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
from django.contrib import messages
from django.urls import reverse
from django.http import JsonResponse
# from django.core.exceptions import ObjectDoesNotExist
from django.db import OperationalError
import json
from django.contrib.auth.decorators import login_required
from .models import CartItem
from .forms import SignUpForm, LoginForm
from .models import Product, CartItem, Order
from django.http import JsonResponse
# from django.contrib.auth.decorators import login_required
# from django.shortcuts import redirect, render
# from django.contrib import messages
# from django.contrib.auth import logout
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from .models import CartItem
import json

# # Navigation views
def basic(request):
    return render(request, 'basic.html')

def cloth(request):
    return render(request, 'project.html')

def login_view(request):
    return render(request, 'login.html')


# 🔐 LOGIN
class CustomLoginView(LoginView):
    template_name = 'login.html'
    authentication_form = LoginForm
    redirect_authenticated_user = True

    def get_success_url(self):
        return self.request.POST.get('next') or self.request.GET.get('next') or reverse('cloth')

    def form_invalid(self, form):
        messages.error(self.request, 'Invalid username or password.')
        return super().form_invalid(form)

# 📝 SIGNUP
def signup(request):
    form = SignUpForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        try:
            form.save()
            messages.success(request, 'Account created successfully! Please log in.')
            return redirect('login')
        except OperationalError:
            messages.error(request, 'Something went wrong. Please try again later.')
    return render(request, 'signup.html', {'form': form})

# 🛍️ PRODUCTS
@login_required
def cloth(request):
    products = Product.objects.all()
    return render(request, 'project.html', {'products': products})

# 🧺 VIEW CART
# @login_required
@login_required
def cart_view(request):
    cart_items = CartItem.objects.filter(user=request.user)
    for item in cart_items:
        item.total = item.price * item.quantity
    total_price = sum(item.total for item in cart_items)
    return render(request, 'cart.html', {
        'cart_items': cart_items,
        'total_price': total_price
    })



@login_required
def add_to_cart(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)

            # 🔍 Extract and validate data
            name = data.get("name")
            price = float(data.get("price"))
            quantity = int(data.get("quantity", 1))

            if not name or price <= 0 or quantity <= 0:
                return JsonResponse({'success': False, 'message': 'Invalid item data'}, status=400)

            # 🛒 Create or update cart item
            item, created = CartItem.objects.get_or_create(
                user=request.user,
                name=name,
                defaults={'price': price, 'quantity': quantity}
            )

            if not created:
                item.quantity += quantity
                item.save()

            return JsonResponse({'success': True, 'message': '✅ Item added to cart'})

        except (ValueError, TypeError, json.JSONDecodeError) as e:
            return JsonResponse({'success': False, 'message': f'Error: {str(e)}'}, status=400)

    return JsonResponse({'success': False, 'message': 'Invalid request method'}, status=405)


# ❌ DELETE ITEM
@login_required
def delete_item(request, item_id):
    try:
        item = CartItem.objects.get(id=item_id, user=request.user)
        item.delete()
        return JsonResponse({'success': True, 'message': 'Item removed'})
    except CartItem.DoesNotExist:
        return JsonResponse({'success': False, 'message': 'Item not found'}, status=404)

# ❌ DELETE ALL
@login_required
def delete_all_items(request):
    CartItem.objects.filter(user=request.user).delete()
    return JsonResponse({'success': True, 'message': 'Cart cleared'})

# ✅ CHECKOUT
@login_required
def checkout(request):
    CartItem.objects.filter(user=request.user).delete()
    messages.success(request, 'Order placed successfully!')
    return redirect('cart')

# 💾 SAVE CART
@login_required
def save_cart(request):
    try:
        data = json.loads(request.body)
        CartItem.objects.filter(user=request.user).delete()
        for item in data.get('cart', []):
            CartItem.objects.create(
                user=request.user,
                name=item['name'],
                price=int(item['price']),
                quantity=int(item.get('quantity', 1))
            )
        return JsonResponse({'status': 'saved'})
    except Exception:
        return JsonResponse({'status': 'error'}, status=400)

# 🔄 LOAD CART
@login_required
def load_cart(request):
    items = CartItem.objects.filter(user=request.user)
    return JsonResponse({'cart': [
        {'name': i.name, 'price': i.price, 'quantity': i.quantity} for i in items
    ]})

# 📦 PLACE ORDER
@login_required
def place_order(request):
    try:
        data = json.loads(request.body)
        for item in data.get('cart', []):
            Order.objects.create(
                user=request.user,
                item=item['name'],
                price=int(item['price']),
                quantity=int(item.get('quantity', 1))
            )
        CartItem.objects.filter(user=request.user).delete()
        return JsonResponse({'status': 'order placed'})
    except Exception:
        return JsonResponse({'status': 'error'}, status=400)

# 🗑️ DELETE ACCOUNT
@login_required
def delete_account(request):
    if request.method == 'POST':
        if request.POST.get('username') == request.user.username:
            request.user.delete()
            logout(request)
            messages.success(request, 'Account deleted.')
            return redirect('login')
        messages.error(request, 'Incorrect username.')
    return render(request, 'delete_account.html')

# 🚪 LOGOUT
def logout_view(request):
    logout(request)
    messages.success(request, 'Logged out successfully.')
    return redirect('login')

@login_required
def add_to_cart(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            name = data.get("name")
            price = float(data.get("price"))
            quantity = int(data.get("quantity", 1))

            if not name or price <= 0 or quantity <= 0:
                return JsonResponse({'success': False, 'message': 'Invalid item data'}, status=400)

            item, created = CartItem.objects.get_or_create(
                user=request.user,
                name=name,
                defaults={'price': price, 'quantity': quantity}
            )

            if not created:
                item.quantity += quantity
                item.save()

            return JsonResponse({'success': True, 'message': '✅ Item added to cart'})

        except (ValueError, TypeError, json.JSONDecodeError) as e:
            return JsonResponse({'success': False, 'message': f'Error: {str(e)}'}, status=400)

    return JsonResponse({'success': False, 'message': 'Invalid request method'}, status=405)

@login_required
def load_cart(request):
    items = CartItem.objects.filter(user=request.user)
    return JsonResponse({'cart': [
        {'name': i.name, 'price': i.price, 'quantity': i.quantity} for i in items
    ]})

@login_required
def save_cart(request):
    try:
        data = json.loads(request.body)
        CartItem.objects.filter(user=request.user).delete()
        for item in data.get('cart', []):
            CartItem.objects.create(
                user=request.user,
                name=item['name'],
                price=int(item['price']),
                quantity=int(item.get('quantity', 1))
            )
        return JsonResponse({'status': 'saved'})
    except Exception:
        return JsonResponse({'status': 'error'}, status=400)

@login_required
def place_order(request):
    try:
        data = json.loads(request.body)
        # You can also create Order objects here if needed
        CartItem.objects.filter(user=request.user).delete()
        return JsonResponse({'status': 'order placed'})
    except Exception:
        return JsonResponse({'status': 'error'}, status=400)
