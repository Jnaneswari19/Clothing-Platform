let cart = [];

// Get CSRF token
const csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content');
function getCSRFToken() {
  return document.cookie
    .split(';')
    .find(c => c.trim().startsWith('csrftoken='))
    ?.split('=')[1] || csrfToken;
}

// Toggle cart modal or box
function toggleCart() {
  const modal = document.getElementById('cartModal');
  const box = document.getElementById('cart-container') || document.getElementById('cart-box');

  if (modal) {
    new bootstrap.Modal(modal).show();
    renderCartTable();
  } else if (box) {
    box.style.display = box.style.display === 'none' ? 'block' : 'none';
    updateCartUI();
  }
}

// Add to cart
function addToCart(name, price, quantity = 1) {
  const existing = cart.find(item => item.name === name);
  if (existing) {
    existing.quantity += quantity;
  } else {
    cart.push({ name, price, quantity });
  }
  updateCartUI();
  if (document.cookie.includes('sessionid')) {
    syncCartItemToBackend(name, price, quantity);
  } else {
    alert('🛒 Item added to your session cart. Login to sync!');
  }
}

// Update cart count and UI
function updateCartUI() {
  const cartList = document.getElementById('cart-items');
  const cartCount = document.getElementById('cart-count');
  const cartTotal = document.getElementById('cart-total');

  if (cartCount) cartCount.textContent = cart.reduce((sum, item) => sum + item.quantity, 0);
  if (cartList) {
    cartList.innerHTML = '';
    let total = 0;

    cart.forEach(item => {
      const itemTotal = item.price * item.quantity;
      total += itemTotal;

      const li = document.createElement('li');
      li.className = 'list-group-item d-flex justify-content-between align-items-center';
      li.innerHTML = `
        <div>
          <strong>${item.name}</strong><br> ₹${item.price} × ${item.quantity}
        </div>
        <div class="btn-group">
          <button class="btn btn-sm btn-outline-secondary" onclick="changeQuantity('${item.name}', -1)">−</button>
          <button class="btn btn-sm btn-outline-secondary" onclick="changeQuantity('${item.name}', 1)">+</button>
          <button class="btn btn-sm btn-danger" onclick="removeFromCart('${item.name}')">🗑️</button>
        </div>
      `;
      cartList.appendChild(li);
    });

    if (cartTotal) cartTotal.textContent = `₹${total}`;
  }
}

// Render cart in modal table
function renderCartTable() {
  const tableBody = document.querySelector('#cart-table tbody');
  if (!tableBody) return;

  tableBody.innerHTML = '';
  cart.forEach((item, index) => {
    tableBody.innerHTML += `
      <tr>
        <td>${item.name}</td>
        <td>₹${item.price}</td>
        <td>${item.quantity}</td>
        <td>₹${item.price * item.quantity}</td>
        <td><button class="btn btn-sm btn-danger" onclick="removeItem(${index})">❌</button></td>
      </tr>
    `;
  });

  const cartCount = document.getElementById('cart-count');
  if (cartCount) cartCount.textContent = cart.reduce((sum, item) => sum + item.quantity, 0);
}

// Remove item by index or name
function removeItem(index) {
  cart.splice(index, 1);
  renderCartTable();
  updateCartUI();
}
function removeFromCart(name) {
  cart = cart.filter(item => item.name !== name);
  renderCartTable();
  updateCartUI();
}

// Quantity change
function changeQuantity(name, delta) {
  const item = cart.find(i => i.name === name);
  if (item) {
    item.quantity += delta;
    if (item.quantity <= 0) removeFromCart(name);
    updateCartUI();
    if (document.cookie.includes('sessionid')) {
      syncCartItemToBackend(name, item.price, item.quantity);
    }
  }
}

// Sync one item to backend
function syncCartItemToBackend(name, price, quantity) {
  fetch('/add-to-cart/', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-CSRFToken': getCSRFToken()
    },
    body: JSON.stringify({ name, price, quantity })
  })
  .then(res => res.json())
  .then(data => {
    if (!data.success) alert('❌ ' + data.message);
  })
  .catch(err => {
    console.error('Sync error:', err);
    alert('⚠️ Could not sync cart item.');
  });
}

// Checkout and clear
function checkout() {
  if (document.cookie.includes('sessionid')) {
    fetch('/place-order/', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRFToken': getCSRFToken()
      },
      body: JSON.stringify({ cart })
    })
    .then(() => {
      alert('🎉 Order placed!');
      cart = [];
      updateCartUI();
      renderCartTable();
    });
  } else {
    alert('Please login to place your order.');
  }
}

// Load cart from backend
function loadCartFromBackend() {
  fetch('/load-cart/')
    .then(res => res.json())
    .then(data => {
      cart = data.cart || [];
      updateCartUI();
      renderCartTable();
    });
}

// Initialization
document.addEventListener('DOMContentLoaded', () => {
  if (document.cookie.includes('sessionid')) {
    loadCartFromBackend();
  }

  document.querySelectorAll('.add-to-cart').forEach(button => {
    button.addEventListener('click', () => {
      const name = button.dataset.name;
      const price = parseFloat(button.dataset.price);
      const quantity = parseInt(button.dataset.quantity || 1);

      if (!name || isNaN(price) || isNaN(quantity)) {
        alert('❌ Invalid product data.');
        return;
      }

      addToCart(name, price, quantity);
    });
  });

  const cartToggleBtn = document.getElementById('cart-button');
  if (cartToggleBtn) cartToggleBtn.addEventListener('click', toggleCart);

  const orderBtn = document.getElementById('place-order-btn');
  if (orderBtn) orderBtn.addEventListener('click', checkout);
});
