# from django.shortcuts import render, redirect
# from django.contrib.auth import authenticate, login
# from django.contrib.auth.decorators import login_required
# from django.contrib import messages
# from shoppingapp.forms import UsernamePasswordForm

# # Navigation views
# def basic(request):
#     return render(request, 'basic.html')

# def cloth(request):
#     return render(request, 'project.html')

# def base(request):
#     return render(request, 'base.html')

# def login_page(request):
#     return render(request, 'login.html')
# def login_view(request):
#      return render(request,"login.html")
# # Signup view

# # Login view
# # def login_view(request):
# #     form = UsernamePasswordForm(request.POST or None)
# #     if request.method == 'POST' and form.is_valid():
# #         username = form.cleaned_data['username']
# #         password = form.cleaned_data['password']
# #         user = authenticate(request, username=username, password=password)
# #         if user:
# #             login(request, user)
# #             messages.success(request, f"Welcome back, {user.username}!")
# #             return redirect('basic')
# #         messages.error(request, "Invalid username or password.")
# #     return render(request, 'login.html', {'form': form})

