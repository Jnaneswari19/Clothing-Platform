from django.contrib import admin
from django.urls import path, include  # include is required to delegate URLs

urlpatterns = [
    path('admin/', admin.site.urls),
    path('accounts/', include('shoppingapp.urls')), 
      # Directs /accounts/ to shoppingapp's URL config
]
